# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: UIBasictest.spec.js >> Page Playwright test case
- Location: tests\UIBasictest.spec.js:11:1

# Error details

```
Error: Unexpected browserName "msedge", must be one of "chromium", "firefox" or "webkit"
```